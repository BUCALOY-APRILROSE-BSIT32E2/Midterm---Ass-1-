﻿namespace Midterm_Assignment1_Login.Models
{
    public class User
    {
    }
}
