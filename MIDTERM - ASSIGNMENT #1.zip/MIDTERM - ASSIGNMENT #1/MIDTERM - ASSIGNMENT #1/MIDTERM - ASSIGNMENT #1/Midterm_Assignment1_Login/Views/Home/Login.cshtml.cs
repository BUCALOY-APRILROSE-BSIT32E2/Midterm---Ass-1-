using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Midterm_Assignment1_Login.Views.Home
{
    public class LoginModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
